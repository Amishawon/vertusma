(() => {
  'use strict';

  const $ = (selector, scope = document) => scope?.querySelector(selector);
  const $$ = (selector, scope = document) => [...(scope?.querySelectorAll(selector) || [])];

  const header = $('#siteHeader');
  const navToggle = $('#navToggle');
  const navLinks = $('#navLinks');
  const propertyGrid = $('#propertyGrid');
  const filters = $('#propertyFilters');
  const propertySearch = $('#propertySearchPublic');
  const clearPortfolioSearch = $('#clearPortfolioSearch');
  const form = $('#inquiryForm');
  const backToTop = $('#backToTop');
  const floatingContact = $('.floating-contact');

  let properties = [];
  let selectedType = 'All';
  let searchTerm = '';
  let heroSlides = [];
  let heroIndex = 0;
  let heroTimer = null;
  let siteConfig = null;
  const HERO_DELAY = 7000;

  function escapeHtml(value) {
    return String(value ?? '')
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#039;');
  }

  function safeUrl(value, fallback = '/') {
    const url = String(value || '').trim();
    if (url.startsWith('/') || url.startsWith('#') || /^https?:\/\//i.test(url) || /^mailto:/i.test(url)) return url;
    return fallback;
  }

  function formatNumber(value) {
    return Number(value || 0).toLocaleString('en-US');
  }

  function text(selector, value) {
    const node = $(selector);
    if (node && value !== undefined && value !== null) node.textContent = String(value);
  }

  function link(selector, label, url) {
    const node = $(selector);
    if (!node) return;
    if (label !== undefined) node.textContent = String(label || '');
    if (url !== undefined) node.setAttribute('href', safeUrl(url, '/'));
  }

  function setSectionEnabled(selector, enabled) {
    const node = $(selector);
    if (node) node.classList.toggle('hide', enabled === false);
  }

  function renderSimpleCards(hostSelector, items, type) {
    const host = $(hostSelector);
    if (!host || !Array.isArray(items)) return;
    if (type === 'services') {
      host.innerHTML = items.map((item, index) => `<article class="service-card"><div class="service-number"><span>${String(index + 1).padStart(2, '0')}</span><span class="service-icon">◆</span></div><h3>${escapeHtml(item.title)}</h3><p>${escapeHtml(item.description)}</p></article>`).join('');
    } else if (type === 'values') {
      host.innerHTML = items.map((item, index) => `<article class="value-card"><span class="value-index">${String(index + 1).padStart(2, '0')}</span><div><h3>${escapeHtml(item.title)}</h3><p>${escapeHtml(item.description)}</p></div></article>`).join('');
    } else if (type === 'process') {
      host.innerHTML = items.map((item, index) => `<article class="process-card"><small>STEP ${String(index + 1).padStart(2, '0')}</small><h3>${escapeHtml(item.title)}</h3><p>${escapeHtml(item.description)}</p></article>`).join('');
    }
  }

  function renderInclusiveMedia(media = {}) {
    const host = $('#inclusiveMediaGrid');
    if (!host) return;
    setSectionEnabled('#inclusiveMediaSection', media.enabled);
    text('#inclusiveMediaEyebrow', media.eyebrow);
    text('#inclusiveMediaTitle', media.title);
    text('#inclusiveMediaDescription', media.description);
    const items = Array.isArray(media.items) ? media.items : [];
    host.innerHTML = items.map((item, index) => {
      const videoUrl = safeUrl(item.video_url, '');
      const hasVideo = /^https?:\/\//i.test(videoUrl);
      return `<article class="experience-media-card reveal-item">
        <div class="experience-media">
          <img src="${escapeHtml(item.image_url || '')}" alt="${escapeHtml(item.image_alt || item.title || item.category || 'Vertusma property experience')}" loading="lazy">
          ${hasVideo ? `<button class="media-play" type="button" data-media-video="${escapeHtml(videoUrl)}" data-media-category="${escapeHtml(item.category || 'Vertusma Experience')}" data-media-title="${escapeHtml(item.title || 'Property experience')}" aria-label="${escapeHtml(item.video_label || `Watch ${item.category || 'property'} experience`)}"><span>▶</span><small>${escapeHtml(item.video_label || 'Watch video')}</small></button>` : ''}
        </div>
        <div class="experience-media-body"><span>${escapeHtml(item.category || '')}</span><h3>${escapeHtml(item.title || '')}</h3><p>${escapeHtml(item.description || '')}</p></div>
      </article>`;
    }).join('');
  }

  function customSectionMarkup(section) {
    const themeClass = { ivory: 'section-sand', navy: 'section-dark', executive: 'section-forest', white: '' }[section.theme] || 'section-sand';
    const body = String(section.body || '').split(/\n{2,}/).filter(Boolean).map(paragraph => `<p>${escapeHtml(paragraph).replaceAll('\n', '<br>')}</p>`).join('');
    const image = section.image_url ? `<div class="custom-section-image"><img src="${escapeHtml(section.image_url)}" alt="${escapeHtml(section.title)}" loading="lazy"></div>` : '';
    const button = section.button_label ? `<a class="btn ${themeClass ? 'btn-secondary' : 'btn-primary'}" href="${escapeHtml(safeUrl(section.button_url, '/contact'))}">${escapeHtml(section.button_label)}</a>` : '';
    return `<section class="section custom-cms-section ${themeClass}" id="${escapeHtml(section.anchor)}"><div class="container grid custom-section-grid"><div class="custom-section-copy">${section.eyebrow ? `<div class="eyebrow">${escapeHtml(section.eyebrow)}</div>` : ''}<h2>${escapeHtml(section.title)}</h2>${body}${button}</div>${image}</div></section>`;
  }

  function applyTheme(theme = {}) {
    const root = document.documentElement.style;
    const map = {
      '--ink': theme.deep_navy, '--forest': theme.deep_navy, '--ink-2': theme.executive_navy, '--forest-2': theme.executive_navy,
      '--gold': theme.heritage_gold, '--gold-deep': theme.heritage_gold, '--gold-soft': theme.soft_gold, '--sand': theme.ivory,
      '--cream': theme.white, '--white': theme.white, '--muted': theme.muted_text, '--muted-2': theme.secondary_muted,
      '--line': theme.border, '--body': theme.body_text, '--footer': theme.footer_bg, '--footer-copy': theme.footer_text
    };
    Object.entries(map).forEach(([key, value]) => { if (value) root.setProperty(key, value); });
    const metaTheme = $('meta[name="theme-color"]');
    if (metaTheme && theme.deep_navy) metaTheme.content = theme.deep_navy;
  }

  function applySiteConfig(config, customSections = []) {
    siteConfig = config || {};
    const identity = siteConfig.identity || {};
    document.title = identity.meta_title || document.title;
    const metaDescription = $('#siteMetaDescription');
    if (metaDescription && identity.meta_description) metaDescription.content = identity.meta_description;
    const favicon = $('#siteFavicon');
    if (favicon && identity.favicon_url) favicon.href = identity.favicon_url;
    $$('.logo img, .footer-logo img').forEach(img => { if (identity.logo_url) img.src = identity.logo_url; if (identity.site_name) img.alt = identity.site_name; });
    applyTheme(siteConfig.theme || {});

    const nav = siteConfig.navigation || {};
    if (navLinks && Array.isArray(nav.items)) {
      const navItems = nav.items.map(item => `<a href="${escapeHtml(safeUrl(item.url, '/'))}" data-cms-nav>${escapeHtml(item.label)}</a>`).join('');
      navLinks.innerHTML = `${navItems}<a href="${escapeHtml(safeUrl(nav.cta_url, '/contact'))}" class="btn btn-premium">${escapeHtml(nav.cta_label || 'Discuss Your Property')}</a>`;
    }

    const extras = siteConfig.hero_extras || {};
    text('#heroStat2Value', extras.stat_2_value); text('#heroStat2Label', extras.stat_2_label);
    text('#heroStat3Value', extras.stat_3_value); text('#heroStat3Label', extras.stat_3_label); text('#heroScrollLabel', extras.scroll_label);

    const about = siteConfig.about || {};
    setSectionEnabled('#about', about.enabled); text('#aboutEyebrow', about.eyebrow); text('#aboutTitle', about.title);
    text('#aboutParagraph1', about.paragraph_1); text('#aboutParagraph2', about.paragraph_2); link('#aboutButton', about.button_label, about.button_url);
    text('#aboutNoteTitle', about.note_title); text('#aboutNoteText', about.note_text);
    const aboutImage = $('#aboutImage'); if (aboutImage && about.image_url) aboutImage.style.backgroundImage = `url("${String(about.image_url).replaceAll('"', '%22')}")`;
    if (aboutImage && about.image_alt) aboutImage.setAttribute('aria-label', about.image_alt);

    const services = siteConfig.services || {};
    setSectionEnabled('#services', services.enabled); text('#servicesEyebrow', services.eyebrow); text('#servicesTitle', services.title); link('#servicesButton', services.button_label, services.button_url); renderSimpleCards('#servicesGrid', services.items, 'services');
    renderInclusiveMedia(siteConfig.inclusive_media || {});
    const metrics = siteConfig.metrics || {};
    setSectionEnabled('#metricsSection', metrics.enabled); text('#metricsLabel', metrics.label); text('#metricsTitle', metrics.title); text('#metricPropertiesLabel', metrics.properties_label); text('#metricSectorsLabel', metrics.sectors_label); text('#metricUnitsLabel', metrics.units_label); text('#metricAreaLabel', metrics.area_label);
    const portfolio = siteConfig.portfolio || {};
    setSectionEnabled('#portfolio', portfolio.enabled); text('#portfolioEyebrow', portfolio.eyebrow); text('#portfolioTitle', portfolio.title); link('#portfolioButton', portfolio.button_label, portfolio.button_url); if (propertySearch && portfolio.search_placeholder) propertySearch.placeholder = portfolio.search_placeholder;

    const mission = siteConfig.mission || {};
    setSectionEnabled('#mission', mission.enabled); text('#missionEyebrow', mission.eyebrow); text('#missionTitle', mission.title); text('#missionStatementTitle', mission.mission_title); text('#missionP1', mission.mission_p1); text('#missionP2', mission.mission_p2); text('#visionTitle', mission.vision_title); text('#visionP1', mission.vision_p1); text('#visionP2', mission.vision_p2); text('#legacyTitle', mission.legacy_title); text('#legacyText', mission.legacy_text);
    const values = siteConfig.values || {};
    setSectionEnabled('#values', values.enabled); text('#valuesEyebrow', values.eyebrow); text('#valuesTitle', values.title); renderSimpleCards('#valuesGrid', values.items, 'values');
    const process = siteConfig.process || {};
    setSectionEnabled('#processSection', process.enabled); text('#processEyebrow', process.eyebrow); text('#processTitle', process.title); renderSimpleCards('#processGrid', process.items, 'process');
    const testimonial = siteConfig.testimonial || {};
    setSectionEnabled('#testimonialSection', testimonial.enabled); text('#testimonialEyebrow', testimonial.eyebrow); text('#testimonialQuote', testimonial.quote ? `“${testimonial.quote}”` : ''); text('#testimonialAuthor', testimonial.author); text('#testimonialRole', testimonial.role);
    const testimonialImage = $('#testimonialImage'); if (testimonialImage && testimonial.image_url) testimonialImage.style.backgroundImage = `url("${String(testimonial.image_url).replaceAll('"', '%22')}")`;
    const cta = siteConfig.cta || {};
    setSectionEnabled('#ctaSection', cta.enabled); text('#ctaEyebrow', cta.eyebrow); text('#ctaTitle', cta.title); link('#ctaPrimary', cta.primary_label, cta.primary_url); link('#ctaSecondary', cta.secondary_label, cta.secondary_url);
    const contact = siteConfig.contact || {};
    setSectionEnabled('#contact', contact.enabled); text('#contactEyebrow', contact.eyebrow); text('#contactTitle', contact.title); text('#contactDescription', contact.description); text('#contactEmail', contact.email); text('#contactServiceArea', contact.service_area); text('#contactSectors', contact.sectors);
    const interest = $('#interest'); if (interest && Array.isArray(contact.interest_options)) interest.innerHTML = '<option value="">Select one</option>' + contact.interest_options.map(item => `<option>${escapeHtml(item)}</option>`).join('');
    text('#submitInquiry', contact.submit_label || 'Send Inquiry');
    const floating = siteConfig.floating_cta || {}; setSectionEnabled('#floatingContactLink', floating.enabled); link('#floatingContactLink', undefined, floating.url); text('#floatingContactLabel', floating.label);

    const footer = siteConfig.footer || {};
    text('#footerCopy', footer.copy); text('#footerCompanyTitle', footer.company_title); text('#footerSectorsTitle', footer.sectors_title); text('#footerConnectTitle', footer.connect_title); text('#footerCopyright', footer.copyright); text('#footerTagline', footer.bottom_tagline);
    const companyLinks = $('#footerCompanyLinks'); if (companyLinks && Array.isArray(footer.company_links)) companyLinks.innerHTML = footer.company_links.map(item => `<a href="${escapeHtml(safeUrl(item.url, '/'))}">${escapeHtml(item.label)}</a>`).join('');
    const footerSectors = $('#footerSectors'); if (footerSectors && Array.isArray(footer.sectors)) footerSectors.innerHTML = footer.sectors.map(item => `<span>${escapeHtml(item)}</span>`).join('');
    const connectLinks = $('#footerConnectLinks'); if (connectLinks) connectLinks.innerHTML = `${contact.email ? `<a href="mailto:${escapeHtml(contact.email)}">${escapeHtml(contact.email)}</a>` : ''}${footer.location ? `<span>${escapeHtml(footer.location)}</span>` : ''}${footer.show_admin_link ? '<a href="/admin">Admin Portal</a>' : ''}`;

    const customHost = $('#customSectionsHost'); if (customHost) customHost.innerHTML = Array.isArray(customSections) ? customSections.map(customSectionMarkup).join('') : '';
    const main = $('main');
    if (main && Array.isArray(siteConfig.homepage_order)) {
      siteConfig.homepage_order.forEach(id => { const section = document.getElementById(id); if (section && section !== $('#home')) main.appendChild(section); });
    }
    setActiveNavigation();
  }

  async function loadSiteConfig() {
    try {
      const response = await fetch('/api/site-config');
      if (!response.ok) throw new Error('Unable to load website content');
      const data = await response.json();
      applySiteConfig(data.config || {}, data.custom_sections || []);
    } catch (error) { console.warn(error); }
  }

  function compactNumber(value) {
    const number = Number(value || 0);
    if (number >= 1_000_000) return `${(number / 1_000_000).toFixed(number >= 10_000_000 ? 0 : 1)}M+`;
    if (number >= 1_000) return `${(number / 1_000).toFixed(number >= 100_000 ? 0 : 1)}K+`;
    return formatNumber(number);
  }

  function setHeaderState() {
    header?.classList.toggle('scrolled', window.scrollY > 24);
    backToTop?.classList.toggle('show', window.scrollY > 650);
    floatingContact?.classList.toggle('show', window.scrollY > 420);
  }

  function closeMenu() {
    navLinks?.classList.remove('open');
    document.body.classList.remove('menu-open');
    navToggle?.setAttribute('aria-expanded', 'false');
  }

  navToggle?.addEventListener('click', () => {
    const open = navLinks.classList.toggle('open');
    document.body.classList.toggle('menu-open', open);
    navToggle.setAttribute('aria-expanded', String(open));
  });

  navLinks?.addEventListener('click', event => { if (event.target.closest('a')) closeMenu(); });
  window.addEventListener('scroll', setHeaderState, { passive: true });
  setHeaderState();
  backToTop?.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));

  // Inclusive residential / commercial / hospitality media ------------------
  const mediaModal = $('#mediaModal');
  const mediaModalVideo = $('#mediaModalVideo');
  function closeMediaModal() {
    if (!mediaModal) return;
    mediaModal.classList.remove('show');
    mediaModal.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('media-modal-open');
    if (mediaModalVideo) { mediaModalVideo.pause(); mediaModalVideo.removeAttribute('src'); mediaModalVideo.load(); }
  }
  function openMediaModal(button) {
    if (!mediaModal || !mediaModalVideo) return;
    const url = safeUrl(button.dataset.mediaVideo, '');
    if (!/^https?:\/\//i.test(url)) return;
    text('#mediaModalCategory', button.dataset.mediaCategory || 'Vertusma Experience');
    text('#mediaModalTitle', button.dataset.mediaTitle || 'Property experience');
    mediaModalVideo.src = url;
    mediaModal.classList.add('show');
    mediaModal.setAttribute('aria-hidden', 'false');
    document.body.classList.add('media-modal-open');
    mediaModalVideo.play().catch(() => {});
  }
  document.addEventListener('click', event => {
    const play = event.target.closest('[data-media-video]');
    if (play) { openMediaModal(play); return; }
    if (event.target.closest('[data-close-media-modal]')) closeMediaModal();
  });
  document.addEventListener('keydown', event => { if (event.key === 'Escape') closeMediaModal(); });

  // Dynamic hero slider -------------------------------------------------------
  function heroSlideMarkup(slide, index) {
    const title = escapeHtml(slide.title || 'Properties cared for.');
    const highlight = escapeHtml(slide.highlight || 'Value built to last.');
    const image = escapeHtml(slide.image_url || 'https://images.pexels.com/photos/7578877/pexels-photo-7578877.jpeg?auto=compress&cs=tinysrgb&w=2200');
    return `
      <article class="hero-slide${index === 0 ? ' active' : ''}" data-slide-index="${index}" style="--hero-image:url('${image.replaceAll("'", '%27')}')" aria-hidden="${index === 0 ? 'false' : 'true'}">
        <div class="container hero-slide-inner">
          <div class="hero-content">
            <div class="eyebrow">${escapeHtml(slide.eyebrow || 'Real Estate · Asset Management · Hospitality')}</div>
            <h1>${title}${highlight ? `<br><span>${highlight}</span>` : ''}</h1>
            <p class="lead">${escapeHtml(slide.description || '')}</p>
            <div class="hero-actions">
              <a href="${escapeHtml(safeUrl(slide.primary_url, '/portfolio'))}" class="btn btn-primary">${escapeHtml(slide.primary_label || 'Explore Our Portfolio')}<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg></a>
              <a href="${escapeHtml(safeUrl(slide.secondary_url, '/contact'))}" class="btn btn-secondary">${escapeHtml(slide.secondary_label || 'Partner With Vertusma')}</a>
            </div>
          </div>
        </div>
      </article>`;
  }

  function resetHeroTimer() {
    window.clearInterval(heroTimer);
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (heroSlides.length > 1 && !reduceMotion) heroTimer = window.setInterval(() => showHeroSlide(heroIndex + 1), HERO_DELAY);
  }

  function showHeroSlide(index, userInitiated = false) {
    if (!heroSlides.length) return;
    heroIndex = (index + heroSlides.length) % heroSlides.length;
    $$('.hero-slide', $('#heroSlides')).forEach((slide, i) => {
      const active = i === heroIndex;
      slide.classList.toggle('active', active);
      slide.setAttribute('aria-hidden', String(!active));
    });
    $$('.hero-dot', $('#heroPagination')).forEach((dot, i) => {
      dot.classList.toggle('active', i === heroIndex);
      dot.setAttribute('aria-current', i === heroIndex ? 'true' : 'false');
    });
    const current = $('#heroCurrent');
    if (current) current.textContent = String(heroIndex + 1).padStart(2, '0');
    const progress = $('#heroProgress');
    if (progress) {
      progress.style.animation = 'none';
      void progress.offsetWidth;
      progress.style.animation = heroSlides.length > 1 ? `heroProgress ${HERO_DELAY}ms linear forwards` : 'none';
    }
    if (userInitiated) resetHeroTimer();
  }

  function setupHeroControls() {
    const pagination = $('#heroPagination');
    if (pagination) {
      pagination.innerHTML = heroSlides.map((slide, index) => `<button class="hero-dot${index === 0 ? ' active' : ''}" type="button" data-hero-dot="${index}" aria-label="Show slide ${index + 1}" aria-current="${index === 0 ? 'true' : 'false'}"><span>${String(index + 1).padStart(2, '0')}</span></button>`).join('');
      pagination.addEventListener('click', event => {
        const dot = event.target.closest('[data-hero-dot]');
        if (dot) showHeroSlide(Number(dot.dataset.heroDot), true);
      });
    }
    const total = $('#heroTotal');
    if (total) total.textContent = String(heroSlides.length || 1).padStart(2, '0');
    $('#heroPrev')?.addEventListener('click', () => showHeroSlide(heroIndex - 1, true));
    $('#heroNext')?.addEventListener('click', () => showHeroSlide(heroIndex + 1, true));

    const hero = $('#home');
    hero?.addEventListener('mouseenter', () => window.clearInterval(heroTimer));
    hero?.addEventListener('mouseleave', resetHeroTimer);
    hero?.addEventListener('focusin', () => window.clearInterval(heroTimer));
    hero?.addEventListener('focusout', resetHeroTimer);

    let touchStartX = 0;
    hero?.addEventListener('touchstart', event => { touchStartX = event.changedTouches[0].clientX; }, { passive: true });
    hero?.addEventListener('touchend', event => {
      const delta = event.changedTouches[0].clientX - touchStartX;
      if (Math.abs(delta) > 55) showHeroSlide(heroIndex + (delta < 0 ? 1 : -1), true);
    }, { passive: true });
  }

  async function loadHeroSlides() {
    const slidesHost = $('#heroSlides');
    if (!slidesHost) return;
    try {
      const response = await fetch('/api/hero-slides');
      if (!response.ok) throw new Error('Unable to load hero slides');
      const data = await response.json();
      if (Array.isArray(data.slides) && data.slides.length) {
        heroSlides = data.slides;
        slidesHost.innerHTML = heroSlides.map(heroSlideMarkup).join('');
      } else {
        heroSlides = [{}];
      }
    } catch (error) {
      heroSlides = [{}];
      console.warn(error);
    }
    setupHeroControls();
    showHeroSlide(0);
    resetHeroTimer();
  }

  // Dynamic portfolio ---------------------------------------------------------
  function propertyCard(property) {
    const image = property.image_url || 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&w=1200&q=80';
    const metrics = [];
    if (property.units) metrics.push(`<span>${formatNumber(property.units)} ${property.property_type === 'Hospitality' ? 'keys' : 'units'}</span>`);
    if (property.square_feet) metrics.push(`<span>${formatNumber(property.square_feet)} sq ft</span>`);

    return `
      <article class="property-card reveal-item">
        <div class="property-media">
          <img src="${escapeHtml(image)}" alt="${escapeHtml(property.title)}" loading="lazy">
          <span class="property-badge">${escapeHtml(property.property_type)}</span>
          ${property.featured ? '<span class="featured-badge">Featured</span>' : ''}
        </div>
        <div class="property-body">
          <div class="property-location">${escapeHtml(property.city)}, ${escapeHtml(property.state)} · ${escapeHtml(property.status)}</div>
          <h3>${escapeHtml(property.title)}</h3>
          ${property.price ? `<div class="property-price">${escapeHtml(property.price)}</div>` : ''}
          <p>${escapeHtml(property.short_description)}</p>
          <div class="property-meta">${metrics.join('')}</div>
          <span class="property-view">Explore property <b>↗</b></span>
        </div>
        <a class="property-link" href="/property/${encodeURIComponent(property.slug)}" aria-label="View ${escapeHtml(property.title)}"></a>
      </article>`;
  }

  function filteredProperties() {
    const term = searchTerm.toLowerCase();
    return properties.filter(item => {
      const typeMatches = selectedType === 'All' || item.property_type === selectedType;
      const searchMatches = !term || [item.title, item.city, item.state, item.property_type, item.status, item.address, item.short_description]
        .some(value => String(value || '').toLowerCase().includes(term));
      return typeMatches && searchMatches;
    });
  }

  function renderProperties() {
    if (!propertyGrid) return;
    const visible = filteredProperties();
    propertyGrid.innerHTML = visible.length
      ? visible.map(propertyCard).join('')
      : '<div class="empty-state"><h3>No properties match your search.</h3><p>Try a different sector, city, state, or property name.</p></div>';
    const result = $('#portfolioResultCount');
    if (result) result.textContent = `Showing ${visible.length} of ${properties.length} ${properties.length === 1 ? 'property' : 'properties'}`;
    clearPortfolioSearch?.classList.toggle('hide', !searchTerm);
    observeReveals(propertyGrid);
  }

  function renderFilterCounts() {
    if (!filters) return;
    const types = [...new Set(properties.map(item => item.property_type).filter(Boolean))].sort((a, b) => a.localeCompare(b));
    const allTypes = ['All', ...types];
    filters.innerHTML = allTypes.map(type => {
      const count = type === 'All' ? properties.length : properties.filter(item => item.property_type === type).length;
      return `<button class="filter-btn${type === selectedType ? ' active' : ''}" data-type="${escapeHtml(type)}">${escapeHtml(type)} <span>${count || ''}</span></button>`;
    }).join('');
    if (selectedType !== 'All' && !types.includes(selectedType)) selectedType = 'All';
  }
  function updatePortfolioMetrics() {
    const sectors = new Set(properties.map(item => item.property_type).filter(Boolean));
    const units = properties.reduce((sum, item) => sum + Number(item.units || 0), 0);
    const area = properties.reduce((sum, item) => sum + Number(item.square_feet || 0), 0);
    animateMetric($('#metricProperties'), properties.length, value => formatNumber(value));
    animateMetric($('#metricSectors'), sectors.size, value => formatNumber(value));
    animateMetric($('#metricUnits'), units, value => compactNumber(value));
    animateMetric($('#metricArea'), area, value => compactNumber(value));
    const heroSectorCount = $('#heroSectorCount');
    if (heroSectorCount && sectors.size) heroSectorCount.textContent = String(sectors.size);
  }

  function animateMetric(node, target, formatter) {
    if (!node) return;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      node.textContent = formatter(target);
      return;
    }
    const started = performance.now();
    const duration = 900;
    const tick = now => {
      const progress = Math.min(1, (now - started) / duration);
      const eased = 1 - Math.pow(1 - progress, 3);
      node.textContent = formatter(Math.round(target * eased));
      if (progress < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }

  async function loadProperties() {
    if (!propertyGrid) return;
    try {
      const response = await fetch('/api/properties');
      if (!response.ok) throw new Error('Unable to load properties');
      const data = await response.json();
      properties = data.properties || [];
      renderFilterCounts();
      updatePortfolioMetrics();
      renderProperties();
    } catch (error) {
      propertyGrid.innerHTML = '<div class="empty-state"><h3>Portfolio unavailable.</h3><p>Please refresh the page or try again shortly.</p></div>';
      const result = $('#portfolioResultCount');
      if (result) result.textContent = 'Portfolio data is temporarily unavailable.';
      console.error(error);
    }
  }

  filters?.addEventListener('click', event => {
    const button = event.target.closest('[data-type]');
    if (!button || button.classList.contains('has-zero')) return;
    selectedType = button.dataset.type;
    $$('.filter-btn', filters).forEach(item => item.classList.toggle('active', item === button));
    renderProperties();
  });

  propertySearch?.addEventListener('input', event => {
    searchTerm = event.target.value.trim();
    renderProperties();
  });

  clearPortfolioSearch?.addEventListener('click', () => {
    searchTerm = '';
    if (propertySearch) propertySearch.value = '';
    propertySearch?.focus();
    renderProperties();
  });

  // Contact form --------------------------------------------------------------
  function clearErrors() {
    $$('.field-error', form).forEach(node => { node.textContent = ''; });
    $('#formStatus')?.classList.remove('show', 'success', 'error');
  }

  function setFormStatus(message, kind) {
    const status = $('#formStatus');
    if (!status) return;
    status.textContent = message;
    status.className = `form-status show ${kind}`;
  }

  form?.addEventListener('submit', async event => {
    event.preventDefault();
    clearErrors();
    const button = $('#submitInquiry');
    const originalText = button.textContent;
    button.disabled = true;
    button.textContent = 'Sending…';

    const payload = Object.fromEntries(new FormData(form).entries());
    try {
      const response = await fetch('/api/inquiries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await response.json();
      if (!response.ok) {
        if (data.details) {
          Object.entries(data.details).forEach(([field, message]) => {
            const error = $(`[data-error="${CSS.escape(field)}"]`, form);
            if (error) error.textContent = message;
          });
        }
        throw new Error(data.error || 'Unable to send inquiry');
      }
      form.reset();
      setFormStatus(data.message, 'success');
    } catch (error) {
      setFormStatus(error.message || 'Something went wrong. Please try again.', 'error');
    } finally {
      button.disabled = false;
      button.textContent = originalText;
    }
  });

  // Motion & navigation -------------------------------------------------------
  let revealObserver;
  function observeReveals(scope = document) {
    if (!('IntersectionObserver' in window) || window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      $$('.reveal-item', scope).forEach(item => item.classList.add('revealed'));
      return;
    }
    if (!revealObserver) {
      revealObserver = new IntersectionObserver(entries => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.classList.add('revealed');
            revealObserver.unobserve(entry.target);
          }
        });
      }, { threshold: 0.12, rootMargin: '0px 0px -30px' });
    }
    $$('.reveal-item', scope).forEach(item => revealObserver.observe(item));
  }

  function prepareReveals() {
    $$('.section > .container, .section-sm > .container, .portfolio-intelligence-grid').forEach((item, index) => {
      item.classList.add('reveal-item');
      item.style.setProperty('--reveal-delay', `${Math.min(index % 3, 2) * 70}ms`);
    });
    observeReveals();
  }

  function setActiveNavigation() {
    const path = window.location.pathname;
    const route = path === '/' ? 'home' : path.split('/').filter(Boolean)[0];
    $$('[data-route]').forEach(link => link.classList.toggle('active', link.dataset.route === route));
  }

  function scrollForRoute() {
    const routeMap = { '/about': 'about', '/services': 'services', '/portfolio': 'portfolio', '/contact': 'contact' };
    const targetId = routeMap[window.location.pathname];
    if (!targetId) return;
    requestAnimationFrame(() => {
      const target = document.getElementById(targetId);
      if (target) window.scrollTo({ top: target.offsetTop - 74, behavior: 'auto' });
    });
  }

  const year = $('#year');
  if (year) year.textContent = String(new Date().getFullYear());

  async function bootstrap() {
    await loadSiteConfig();
    await Promise.all([loadHeroSlides(), loadProperties()]);
    prepareReveals();
    setActiveNavigation();
    scrollForRoute();
  }

  bootstrap();
})();
