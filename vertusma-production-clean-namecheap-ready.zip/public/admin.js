(() => {
  'use strict';
  const $ = (selector, scope = document) => scope?.querySelector(selector);
  const $$ = (selector, scope = document) => [...(scope?.querySelectorAll(selector) || [])];

  const state = { config: {}, heroSlides: [], properties: [], inquiries: [], sections: [], pages: [], panel: 'overview' };
  const loginScreen = $('#loginScreen');
  const adminShell = $('#adminShell');
  const propertyModal = $('#propertyModal');
  const heroModal = $('#heroModal');
  const sectionModal = $('#sectionModal');
  const pageModal = $('#pageModal');

  const escapeHtml = value => String(value ?? '')
    .replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;').replaceAll("'", '&#039;');
  const formatNumber = value => Number(value || 0).toLocaleString('en-US');
  const formatDate = value => {
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? '—' : date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  };

  async function api(url, options = {}) {
    const response = await fetch(url, {
      credentials: 'same-origin', ...options,
      headers: { ...(options.body ? { 'Content-Type': 'application/json' } : {}), ...(options.headers || {}) }
    });
    let data = {};
    try { data = await response.json(); } catch (_) {}
    if (!response.ok) {
      if (response.status === 401) showLogin();
      const error = new Error(data.error || `Request failed (${response.status})`);
      error.details = data.details;
      throw error;
    }
    return data;
  }

  function showToast(message) {
    const toast = $('#toast');
    toast.textContent = message;
    toast.classList.add('show');
    clearTimeout(showToast.timer);
    showToast.timer = setTimeout(() => toast.classList.remove('show'), 3000);
  }

  function showLogin() { loginScreen.classList.remove('hide'); adminShell.classList.add('hide'); }
  function showAdmin() { loginScreen.classList.add('hide'); adminShell.classList.remove('hide'); }

  function getPath(object, path) {
    return path.split('.').reduce((value, key) => value == null ? undefined : value[key], object);
  }
  function setPath(object, path, value) {
    const keys = path.split('.');
    let cursor = object;
    keys.slice(0, -1).forEach(key => {
      if (!cursor[key] || typeof cursor[key] !== 'object') cursor[key] = {};
      cursor = cursor[key];
    });
    cursor[keys.at(-1)] = value;
  }

  const homepageSectionLabels = {
    about: 'About', services: 'Services', inclusiveMediaSection: 'Diverse People & Media', metricsSection: 'Portfolio Metrics', portfolio: 'Portfolio', mission: 'Mission / Vision',
    values: 'Core Values', processSection: 'How We Work', testimonialSection: 'Testimonial', ctaSection: 'Call to Action',
    customSectionsHost: 'Custom Sections', contact: 'Contact'
  };

  const repeaterSchemas = {
    'navigation.items': [{ key: 'label', label: 'Label' }, { key: 'url', label: 'URL' }],
    'services.items': [{ key: 'title', label: 'Service title' }, { key: 'description', label: 'Description', textarea: true }],
    'inclusive_media.items': [
      { key: 'category', label: 'Sector / category' }, { key: 'title', label: 'Card heading' },
      { key: 'description', label: 'Description', textarea: true },
      { key: 'image_url', label: 'Image URL', upload: true }, { key: 'image_alt', label: 'Image description' },
      { key: 'video_url', label: 'Video URL (HTTPS MP4)' }, { key: 'video_label', label: 'Play button label' }
    ],
    'values.items': [{ key: 'title', label: 'Value' }, { key: 'description', label: 'Description', textarea: true }],
    'process.items': [{ key: 'title', label: 'Step title' }, { key: 'description', label: 'Description', textarea: true }],
    'contact.interest_options': [{ key: '__value', label: 'Option' }],
    'footer.company_links': [{ key: 'label', label: 'Label' }, { key: 'url', label: 'URL' }],
    'footer.sectors': [{ key: '__value', label: 'Sector' }]
  };

  function newRepeaterItem(path) {
    if (path === 'contact.interest_options' || path === 'footer.sectors') return '';
    return Object.fromEntries((repeaterSchemas[path] || []).map(field => [field.key, '']));
  }

  function renderRepeater(path) {
    const host = $(`[data-repeater="${CSS.escape(path)}"]`);
    if (!host) return;
    const schema = repeaterSchemas[path] || [];
    const items = getPath(state.config, path) || [];
    host.innerHTML = items.length ? items.map((item, index) => {
      const fields = schema.map(field => {
        const value = field.key === '__value' ? item : item?.[field.key];
        let control;
        if (field.textarea) control = `<textarea class="form-control" data-repeat-input="${escapeHtml(path)}" data-index="${index}" data-key="${field.key}">${escapeHtml(value)}</textarea>`;
        else if (field.upload) control = `<div class="upload-row"><input class="form-control" data-repeat-input="${escapeHtml(path)}" data-index="${index}" data-key="${field.key}" value="${escapeHtml(value)}"><label class="btn btn-outline upload-control">Upload Image<input type="file" accept="image/jpeg,image/png,image/webp,image/gif" data-upload-repeater="${escapeHtml(path)}" data-index="${index}" data-key="${field.key}"></label></div>`;
        else control = `<input class="form-control" data-repeat-input="${escapeHtml(path)}" data-index="${index}" data-key="${field.key}" value="${escapeHtml(value)}">`;
        return `<div class="form-group"><label>${escapeHtml(field.label)}</label>${control}</div>`;
      }).join('');
      return `<div class="repeater-row ${schema.length > 1 ? 'repeater-wide' : ''}">${fields}<div class="repeater-actions"><button type="button" data-repeat-move="up" data-repeat-path="${escapeHtml(path)}" data-index="${index}" title="Move up">↑</button><button type="button" data-repeat-move="down" data-repeat-path="${escapeHtml(path)}" data-index="${index}" title="Move down">↓</button><button type="button" data-repeat-remove data-repeat-path="${escapeHtml(path)}" data-index="${index}" title="Remove">×</button></div></div>`;
    }).join('') : '<p class="text-muted">No items yet. Use the Add button to create one.</p>';
  }

  function renderHomepageOrder() {
    const host = $('#homepageOrderList'); if (!host) return;
    const order = Array.isArray(state.config.homepage_order) ? state.config.homepage_order : Object.keys(homepageSectionLabels);
    host.innerHTML = order.map((key, index) => `<div class="repeater-row"><div><strong>${escapeHtml(homepageSectionLabels[key] || key)}</strong><div class="table-sub">${escapeHtml(key)}</div></div><div></div><div class="repeater-actions"><button type="button" data-home-order="up" data-index="${index}" title="Move up">↑</button><button type="button" data-home-order="down" data-index="${index}" title="Move down">↓</button></div></div>`).join('');
  }

  function renderRepeaters() { Object.keys(repeaterSchemas).forEach(renderRepeater); renderHomepageOrder(); }

  document.addEventListener('input', event => {
    const field = event.target.closest('[data-repeat-input]');
    if (field) {
      const path = field.dataset.repeatInput;
      const index = Number(field.dataset.index);
      const key = field.dataset.key;
      const items = getPath(state.config, path) || [];
      if (key === '__value') items[index] = field.value;
      else if (items[index]) items[index][key] = field.value;
      setPath(state.config, path, items);
    }
    const configField = event.target.closest('[data-config]');
    if (configField && configField.type !== 'checkbox') {
      setPath(state.config, configField.dataset.config, configField.value);
      const swatch = $(`[data-color-for="${CSS.escape(configField.dataset.config)}"]`);
      if (swatch && /^#[0-9a-f]{6}$/i.test(configField.value)) swatch.value = configField.value;
    }
  });

  document.addEventListener('change', event => {
    const configField = event.target.closest('[data-config]');
    if (configField?.type === 'checkbox') setPath(state.config, configField.dataset.config, configField.checked);
    const swatch = event.target.closest('[data-color-for]');
    if (swatch) {
      setPath(state.config, swatch.dataset.colorFor, swatch.value.toUpperCase());
      const input = $(`[data-config="${CSS.escape(swatch.dataset.colorFor)}"]`);
      if (input) input.value = swatch.value.toUpperCase();
    }
  });

  document.addEventListener('click', event => {
    const homeMove = event.target.closest('[data-home-order]');
    if (homeMove) {
      const order = Array.isArray(state.config.homepage_order) ? [...state.config.homepage_order] : Object.keys(homepageSectionLabels);
      const index = Number(homeMove.dataset.index), target = homeMove.dataset.homeOrder === 'up' ? index - 1 : index + 1;
      if (target >= 0 && target < order.length) [order[index], order[target]] = [order[target], order[index]];
      state.config.homepage_order = order; renderHomepageOrder(); return;
    }
    const add = event.target.closest('[data-add-repeater]');
    if (add) {
      const path = add.dataset.addRepeater;
      const items = getPath(state.config, path) || [];
      items.push(newRepeaterItem(path));
      setPath(state.config, path, items);
      renderRepeater(path);
      return;
    }
    const remove = event.target.closest('[data-repeat-remove]');
    if (remove) {
      const path = remove.dataset.repeatPath, index = Number(remove.dataset.index);
      const items = getPath(state.config, path) || [];
      items.splice(index, 1); setPath(state.config, path, items); renderRepeater(path); return;
    }
    const move = event.target.closest('[data-repeat-move]');
    if (move) {
      const path = move.dataset.repeatPath, index = Number(move.dataset.index);
      const items = getPath(state.config, path) || [];
      const target = move.dataset.repeatMove === 'up' ? index - 1 : index + 1;
      if (target >= 0 && target < items.length) [items[index], items[target]] = [items[target], items[index]];
      setPath(state.config, path, items); renderRepeater(path);
    }
  });

  function applyAdminBranding() {
    const identity = state.config.identity || {}, theme = state.config.theme || {};
    const root = document.documentElement.style;
    const map = { '--ink': theme.deep_navy, '--ink-2': theme.executive_navy, '--forest': theme.deep_navy, '--forest-2': theme.executive_navy, '--gold': theme.heritage_gold, '--gold-deep': theme.heritage_gold, '--gold-soft': theme.soft_gold, '--sand': theme.ivory, '--cream': theme.white, '--white': theme.white, '--muted': theme.muted_text, '--muted-2': theme.secondary_muted, '--line': theme.border, '--body': theme.body_text, '--footer': theme.footer_bg, '--footer-copy': theme.footer_text };
    Object.entries(map).forEach(([key, value]) => { if (value) root.setProperty(key, value); });
    const sidebarLogo = $('.admin-sidebar > img'); if (sidebarLogo && identity.logo_url) sidebarLogo.src = identity.logo_url;
    const mobileLogo = $('.admin-mobile-top img'); if (mobileLogo && identity.logo_url) mobileLogo.src = identity.logo_url;
    const loginLogo = $('.login-card img'); if (loginLogo && identity.logo_dark_url) loginLogo.src = identity.logo_dark_url;
  }

  function populateConfigFields() {
    applyAdminBranding();
    $$('[data-config]').forEach(field => {
      const value = getPath(state.config, field.dataset.config);
      if (field.type === 'checkbox') field.checked = Boolean(value);
      else field.value = value ?? '';
    });
    $$('[data-color-for]').forEach(field => {
      const value = getPath(state.config, field.dataset.colorFor);
      if (/^#[0-9a-f]{6}$/i.test(String(value || ''))) field.value = value;
    });
    renderRepeaters();
  }

  async function saveConfig(button) {
    $$('[data-config]').forEach(field => setPath(state.config, field.dataset.config, field.type === 'checkbox' ? field.checked : field.value));
    const old = button.textContent; button.disabled = true; button.textContent = 'Saving…';
    try {
      const data = await api('/api/admin/site-config', { method: 'PUT', body: JSON.stringify({ config: state.config }) });
      state.config = data.config || state.config; populateConfigFields(); showToast('Website content saved.');
      $('#configSaveStatus').textContent = 'Saved'; $('#appearanceSaveStatus').textContent = 'Saved';
    } catch (error) { showToast(error.message); }
    finally { button.disabled = false; button.textContent = old; }
  }
  $$('[data-save-config]').forEach(button => button.addEventListener('click', () => saveConfig(button)));

  function fileToDataUrl(file) {
    return new Promise((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(reader.result); reader.onerror = reject; reader.readAsDataURL(file); });
  }
  async function uploadFile(file) {
    if (!file) return null;
    const dataUrl = await fileToDataUrl(file);
    const data = await api('/api/admin/upload', { method: 'POST', body: JSON.stringify({ filename: file.name, data_url: dataUrl }) });
    return data.url;
  }

  document.addEventListener('change', async event => {
    const configUpload = event.target.closest('[data-upload-config]');
    const inputUpload = event.target.closest('[data-upload-input]');
    const repeaterUpload = event.target.closest('[data-upload-repeater]');
    if (!configUpload && !inputUpload && !repeaterUpload) return;
    const file = event.target.files?.[0]; if (!file) return;
    const label = event.target.closest('.upload-control');
    const old = label?.childNodes?.[0]?.textContent || 'Upload Image';
    if (label?.childNodes?.[0]) label.childNodes[0].textContent = 'Uploading…';
    try {
      const url = await uploadFile(file);
      if (configUpload) {
        setPath(state.config, configUpload.dataset.uploadConfig, url);
        const target = $(`[data-config="${CSS.escape(configUpload.dataset.uploadConfig)}"]`);
        if (target) target.value = url;
      } else if (repeaterUpload) {
        const path = repeaterUpload.dataset.uploadRepeater, index = Number(repeaterUpload.dataset.index), key = repeaterUpload.dataset.key;
        const items = getPath(state.config, path) || [];
        if (items[index]) items[index][key] = url;
        setPath(state.config, path, items);
        renderRepeater(path);
      } else {
        const target = $(inputUpload.dataset.uploadInput); if (target) target.value = url;
      }
      showToast('Image uploaded. Save the content to publish it.');
    } catch (error) { showToast(error.message); }
    finally { if (label?.childNodes?.[0]) label.childNodes[0].textContent = old; event.target.value = ''; }
  });

  async function checkSession() {
    try {
      const data = await api('/api/admin/session');
      if (data.authenticated) { showAdmin(); await refreshAll(); } else showLogin();
    } catch (_) { showLogin(); }
  }

  $('#loginForm')?.addEventListener('submit', async event => {
    event.preventDefault();
    const status = $('#loginStatus'), button = event.submitter, payload = Object.fromEntries(new FormData(event.currentTarget).entries());
    status.className = 'form-status'; button.disabled = true; button.textContent = 'Signing in…';
    try { await api('/api/admin/login', { method: 'POST', body: JSON.stringify(payload) }); event.currentTarget.reset(); showAdmin(); await refreshAll(); }
    catch (error) { status.textContent = error.message; status.className = 'form-status show error'; }
    finally { button.disabled = false; button.textContent = 'Sign In'; }
  });

  $('#logoutButton')?.addEventListener('click', async () => { try { await api('/api/admin/logout', { method: 'POST', body: '{}' }); } catch (_) {} showLogin(); });

  async function refreshAll() {
    const [configData, heroData, propertyData, inquiryData, sectionData, pageData] = await Promise.all([
      api('/api/admin/site-config'), api('/api/admin/hero-slides'), api('/api/admin/properties'), api('/api/admin/inquiries'), api('/api/admin/custom-sections'), api('/api/admin/pages')
    ]);
    state.config = configData.config || {};
    state.heroSlides = heroData.slides || [];
    state.properties = propertyData.properties || [];
    state.inquiries = inquiryData.inquiries || [];
    state.sections = sectionData.sections || [];
    state.pages = pageData.pages || [];
    populateConfigFields(); renderAll();
  }

  function renderAll() {
    $('#statProperties').textContent = formatNumber(state.properties.length);
    $('#statPublished').textContent = formatNumber(state.properties.filter(item => item.published).length);
    $('#statFeatured').textContent = formatNumber(state.properties.filter(item => item.featured).length);
    $('#statHeroSlides').textContent = formatNumber(state.heroSlides.filter(item => item.active).length);
    $('#statInquiries').textContent = formatNumber(state.inquiries.filter(item => item.status === 'New').length);
    $('#statAllInquiries').textContent = formatNumber(state.inquiries.length);
    $('#statSections').textContent = formatNumber(state.sections.filter(item => item.active).length);
    $('#statPages').textContent = formatNumber(state.pages.filter(item => item.published).length);
    renderHeroSlides(); renderProperties(); renderInquiries(); renderRecentInquiries(); renderSections(); renderPages(); renderPropertyTypeSuggestions();
  }

  function switchPanel(panel) {
    state.panel = panel;
    $$('.admin-panel').forEach(item => item.classList.add('hide'));
    $(`#panel-${panel}`)?.classList.remove('hide');
    $$('[data-panel]').forEach(button => button.classList.toggle('active', button.dataset.panel === panel));
    $('#adminSidebar')?.classList.remove('open');
  }
  $$('[data-panel]').forEach(button => button.addEventListener('click', () => switchPanel(button.dataset.panel)));
  $$('[data-panel-link]').forEach(button => button.addEventListener('click', () => switchPanel(button.dataset.panelLink)));
  $('#adminMenuToggle')?.addEventListener('click', () => $('#adminSidebar')?.classList.toggle('open'));

  // Hero slides
  function renderHeroSlides() {
    const rows = $('#heroSlideRows'); if (!rows) return;
    $('#heroSlideCount').textContent = `${state.heroSlides.length} ${state.heroSlides.length === 1 ? 'slide' : 'slides'}`;
    rows.innerHTML = state.heroSlides.length ? state.heroSlides.map(slide => `<tr><td><div class="admin-media-thumb"><img src="${escapeHtml(slide.image_url)}" alt=""><div><div class="table-title">${escapeHtml(slide.eyebrow || 'Hero slide')}</div><div class="table-sub">Updated ${formatDate(slide.updated_at)}</div></div></div></td><td><div class="table-title">${escapeHtml(slide.title)}</div><div class="table-sub">${escapeHtml(slide.highlight || '')}</div></td><td>${formatNumber(slide.sort_order)}</td><td><span class="status-pill ${slide.active ? '' : 'status-muted'}">${slide.active ? 'Active' : 'Hidden'}</span></td><td><div class="action-row"><button class="icon-btn" data-edit-hero="${slide.id}">✎</button><button class="icon-btn danger" data-delete-hero="${slide.id}">×</button></div></td></tr>`).join('') : '<tr><td colspan="5" class="text-muted">No hero slides yet.</td></tr>';
  }
  function openHeroModal(slide = null) {
    const form = $('#heroForm'); form.reset(); $('#heroFormStatus').className = 'form-status'; $('#heroModalTitle').textContent = slide ? 'Edit Hero Slide' : 'Add Hero Slide';
    if (slide) Object.entries(slide).forEach(([key, value]) => { const field = form.elements.namedItem(key); if (!field) return; field.type === 'checkbox' ? field.checked = Boolean(value) : field.value = value ?? ''; });
    $('#heroId').value = slide?.id || '';
    if (!slide) { $('#heroPrimaryLabel').value='Explore Our Portfolio'; $('#heroPrimaryUrl').value='/portfolio'; $('#heroSecondaryLabel').value='Partner With Vertusma'; $('#heroSecondaryUrl').value='/contact'; $('#heroSortOrder').value=String((state.heroSlides.length+1)*10); $('#heroActive').checked=true; }
    heroModal.classList.add('show'); heroModal.setAttribute('aria-hidden','false');
  }
  const closeHeroModal = () => { heroModal.classList.remove('show'); heroModal.setAttribute('aria-hidden','true'); };
  $$('[data-new-hero]').forEach(b => b.addEventListener('click', () => openHeroModal())); $$('[data-close-hero-modal]').forEach(b => b.addEventListener('click', closeHeroModal));
  heroModal?.addEventListener('click', e => { if (e.target === heroModal) closeHeroModal(); });
  $('#heroForm')?.addEventListener('submit', async event => {
    event.preventDefault(); const data=Object.fromEntries(new FormData(event.currentTarget).entries()); data.active=$('#heroActive').checked; data.sort_order=Number(data.sort_order||0); const id=data.id; delete data.id;
    try { if(id) await api(`/api/admin/hero-slides/${id}`,{method:'PUT',body:JSON.stringify(data)}); else await api('/api/admin/hero-slides',{method:'POST',body:JSON.stringify(data)}); closeHeroModal(); await refreshAll(); switchPanel('hero'); showToast(id?'Hero slide updated.':'Hero slide added.'); }
    catch(error){ const status=$('#heroFormStatus'); status.textContent=error.details?Object.values(error.details)[0]:error.message; status.className='form-status show error'; }
  });
  $('#heroSlideRows')?.addEventListener('click', async event => {
    const edit=event.target.closest('[data-edit-hero]'), remove=event.target.closest('[data-delete-hero]');
    if(edit){const item=state.heroSlides.find(x=>x.id===Number(edit.dataset.editHero)); if(item) openHeroModal(item);}
    if(remove){const item=state.heroSlides.find(x=>x.id===Number(remove.dataset.deleteHero)); if(item&&confirm(`Delete hero slide “${item.title}”?`)){await api(`/api/admin/hero-slides/${item.id}`,{method:'DELETE'}); await refreshAll(); showToast('Hero slide deleted.');}}
  });

  // Properties
  function renderPropertyTypeSuggestions() {
    const host=$('#propertyTypeSuggestions'); if(!host)return; const types=[...new Set(state.properties.map(x=>x.property_type).filter(Boolean))].sort(); host.innerHTML=types.map(x=>`<option value="${escapeHtml(x)}"></option>`).join('');
  }
  function renderProperties() {
    const term=$('#propertySearch')?.value.trim().toLowerCase()||'';
    const items=state.properties.filter(p=>[p.title,p.city,p.state,p.property_type,p.status].some(v=>String(v).toLowerCase().includes(term)));
    $('#propertyRows').innerHTML=items.length?items.map(p=>`<tr><td><div class="table-title">${escapeHtml(p.title)}</div><div class="table-sub">/${escapeHtml(p.slug)}${p.price?` · ${escapeHtml(p.price)}`:''}</div></td><td>${escapeHtml(p.property_type)}</td><td>${escapeHtml(p.city)}, ${escapeHtml(p.state)}</td><td><span class="status-pill">${escapeHtml(p.status)}</span></td><td>${p.published?'Yes':'Draft'}</td><td><div class="action-row">${p.published?`<a class="icon-btn" href="/property/${encodeURIComponent(p.slug)}" target="_blank">↗</a>`:''}<button class="icon-btn" data-edit-property="${p.id}">✎</button><button class="icon-btn danger" data-delete-property="${p.id}">×</button></div></td></tr>`).join(''):'<tr><td colspan="6" class="text-muted">No properties found.</td></tr>';
    $('#propertyCount').textContent=`${items.length} ${items.length===1?'property':'properties'}`;
  }
  $('#propertySearch')?.addEventListener('input',renderProperties);
  function openPropertyModal(property=null){const form=$('#propertyForm');form.reset();$('#propertyFormStatus').className='form-status';$('#propertyModalTitle').textContent=property?'Edit Property':'Add Property';if(property)Object.entries(property).forEach(([k,v])=>{const f=form.elements.namedItem(k);if(!f)return;f.type==='checkbox'?f.checked=Boolean(v):f.value=v??'';});$('#propertyId').value=property?.id||'';if(!property){$('#propertyUnits').value='0';$('#propertyArea').value='0';$('#propertyPublished').checked=true;}propertyModal.classList.add('show');propertyModal.setAttribute('aria-hidden','false');}
  const closePropertyModal=()=>{propertyModal.classList.remove('show');propertyModal.setAttribute('aria-hidden','true');};
  $$('[data-new-property]').forEach(b=>b.addEventListener('click',()=>openPropertyModal()));$$('[data-close-modal]').forEach(b=>b.addEventListener('click',closePropertyModal));propertyModal?.addEventListener('click',e=>{if(e.target===propertyModal)closePropertyModal();});
  $('#propertyForm')?.addEventListener('submit',async event=>{event.preventDefault();const data=Object.fromEntries(new FormData(event.currentTarget).entries());data.featured=$('#propertyFeatured').checked;data.published=$('#propertyPublished').checked;data.units=Number(data.units||0);data.square_feet=Number(data.square_feet||0);const id=data.id;delete data.id;try{if(id)await api(`/api/admin/properties/${id}`,{method:'PUT',body:JSON.stringify(data)});else await api('/api/admin/properties',{method:'POST',body:JSON.stringify(data)});closePropertyModal();await refreshAll();switchPanel('properties');showToast(id?'Property updated.':'Property added.');}catch(error){const status=$('#propertyFormStatus');status.textContent=error.details?Object.values(error.details)[0]:error.message;status.className='form-status show error';}});
  $('#propertyRows')?.addEventListener('click',async event=>{const edit=event.target.closest('[data-edit-property]'),remove=event.target.closest('[data-delete-property]');if(edit){const p=state.properties.find(x=>x.id===Number(edit.dataset.editProperty));if(p)openPropertyModal(p);}if(remove){const p=state.properties.find(x=>x.id===Number(remove.dataset.deleteProperty));if(p&&confirm(`Delete “${p.title}”? This cannot be undone.`)){await api(`/api/admin/properties/${p.id}`,{method:'DELETE'});await refreshAll();showToast('Property deleted.');}}});

  // Custom homepage sections
  function renderSections(){const rows=$('#sectionRows');if(!rows)return;$('#sectionCount').textContent=`${state.sections.length} sections`;rows.innerHTML=state.sections.length?state.sections.map(s=>`<tr><td><div class="table-title">${escapeHtml(s.title)}</div><div class="table-sub">#${escapeHtml(s.anchor)}</div></td><td>${escapeHtml(s.theme)}</td><td>${s.sort_order}</td><td><span class="status-pill ${s.active?'':'status-muted'}">${s.active?'Active':'Hidden'}</span></td><td><div class="action-row"><a class="icon-btn" href="/#${encodeURIComponent(s.anchor)}" target="_blank">↗</a><button class="icon-btn" data-edit-section="${s.id}">✎</button><button class="icon-btn danger" data-delete-section="${s.id}">×</button></div></td></tr>`).join(''):'<tr><td colspan="5" class="text-muted">No custom sections yet.</td></tr>';}
  function openSectionModal(item=null){const form=$('#sectionForm');form.reset();$('#sectionFormStatus').className='form-status';$('#sectionModalTitle').textContent=item?'Edit Custom Section':'Add Custom Section';if(item)Object.entries(item).forEach(([k,v])=>{const f=form.elements.namedItem(k);if(!f)return;f.type==='checkbox'?f.checked=Boolean(v):f.value=v??'';});$('#sectionId').value=item?.id||'';if(!item){form.elements.theme.value='ivory';form.elements.sort_order.value=String((state.sections.length+1)*10+100);$('#sectionActive').checked=true;}sectionModal.classList.add('show');sectionModal.setAttribute('aria-hidden','false');}
  const closeSectionModal=()=>{sectionModal.classList.remove('show');sectionModal.setAttribute('aria-hidden','true');};
  $$('[data-new-section]').forEach(b=>b.addEventListener('click',()=>openSectionModal()));$$('[data-close-section-modal]').forEach(b=>b.addEventListener('click',closeSectionModal));sectionModal?.addEventListener('click',e=>{if(e.target===sectionModal)closeSectionModal();});
  $('#sectionForm')?.addEventListener('submit',async event=>{event.preventDefault();const data=Object.fromEntries(new FormData(event.currentTarget).entries());data.active=$('#sectionActive').checked;data.sort_order=Number(data.sort_order||100);const id=data.id;delete data.id;try{if(id)await api(`/api/admin/custom-sections/${id}`,{method:'PUT',body:JSON.stringify(data)});else await api('/api/admin/custom-sections',{method:'POST',body:JSON.stringify(data)});closeSectionModal();await refreshAll();switchPanel('sections');showToast(id?'Section updated.':'Section added.');}catch(error){const status=$('#sectionFormStatus');status.textContent=error.message;status.className='form-status show error';}});
  $('#sectionRows')?.addEventListener('click',async e=>{const edit=e.target.closest('[data-edit-section]'),remove=e.target.closest('[data-delete-section]');if(edit){const item=state.sections.find(x=>x.id===Number(edit.dataset.editSection));if(item)openSectionModal(item);}if(remove){const item=state.sections.find(x=>x.id===Number(remove.dataset.deleteSection));if(item&&confirm(`Delete section “${item.title}”?`)){await api(`/api/admin/custom-sections/${item.id}`,{method:'DELETE'});await refreshAll();showToast('Section deleted.');}}});

  // Custom pages
  function renderPages(){const rows=$('#pageRows');if(!rows)return;$('#pageCount').textContent=`${state.pages.length} pages`;rows.innerHTML=state.pages.length?state.pages.map(p=>`<tr><td><div class="table-title">${escapeHtml(p.title)}</div><div class="table-sub">${escapeHtml(p.eyebrow||'')}</div></td><td>/page/${escapeHtml(p.slug)}</td><td><span class="status-pill ${p.published?'':'status-muted'}">${p.published?'Published':'Draft'}</span></td><td>${formatDate(p.updated_at)}</td><td><div class="action-row">${p.published?`<a class="icon-btn" href="/page/${encodeURIComponent(p.slug)}" target="_blank">↗</a>`:''}<button class="icon-btn" data-edit-page="${p.id}">✎</button><button class="icon-btn danger" data-delete-page="${p.id}">×</button></div></td></tr>`).join(''):'<tr><td colspan="5" class="text-muted">No custom pages yet.</td></tr>';}
  function openPageModal(item=null){const form=$('#pageForm');form.reset();$('#pageFormStatus').className='form-status';$('#pageModalTitle').textContent=item?'Edit Custom Page':'Add Custom Page';if(item)Object.entries(item).forEach(([k,v])=>{const f=form.elements.namedItem(k);if(!f)return;f.type==='checkbox'?f.checked=Boolean(v):f.value=v??'';});$('#pageId').value=item?.id||'';if(!item)$('#pagePublished').checked=true;pageModal.classList.add('show');pageModal.setAttribute('aria-hidden','false');}
  const closePageModal=()=>{pageModal.classList.remove('show');pageModal.setAttribute('aria-hidden','true');};
  $$('[data-new-page]').forEach(b=>b.addEventListener('click',()=>openPageModal()));$$('[data-close-page-modal]').forEach(b=>b.addEventListener('click',closePageModal));pageModal?.addEventListener('click',e=>{if(e.target===pageModal)closePageModal();});
  $('#pageForm')?.addEventListener('submit',async event=>{event.preventDefault();const data=Object.fromEntries(new FormData(event.currentTarget).entries());data.published=$('#pagePublished').checked;const id=data.id;delete data.id;try{if(id)await api(`/api/admin/pages/${id}`,{method:'PUT',body:JSON.stringify(data)});else await api('/api/admin/pages',{method:'POST',body:JSON.stringify(data)});closePageModal();await refreshAll();switchPanel('pages');showToast(id?'Page updated.':'Page created.');}catch(error){const status=$('#pageFormStatus');status.textContent=error.message;status.className='form-status show error';}});
  $('#pageRows')?.addEventListener('click',async e=>{const edit=e.target.closest('[data-edit-page]'),remove=e.target.closest('[data-delete-page]');if(edit){const item=state.pages.find(x=>x.id===Number(edit.dataset.editPage));if(item)openPageModal(item);}if(remove){const item=state.pages.find(x=>x.id===Number(remove.dataset.deletePage));if(item&&confirm(`Delete page “${item.title}”?`)){await api(`/api/admin/pages/${item.id}`,{method:'DELETE'});await refreshAll();showToast('Page deleted.');}}});

  // Inquiries
  function inquiryRows(items){if(!items.length)return'<tr><td colspan="5" class="text-muted">No inquiries found.</td></tr>';const statuses=['New','Contacted','Qualified','Closed'];return items.map(i=>`<tr><td><div class="table-title">${escapeHtml(i.name)}</div><div class="table-sub"><a href="mailto:${escapeHtml(i.email)}">${escapeHtml(i.email)}</a>${i.phone?` · ${escapeHtml(i.phone)}`:''}</div></td><td><div class="table-title">${escapeHtml(i.interest)}</div><div class="inquiry-message">${escapeHtml(i.message)}</div></td><td><select class="form-control" style="min-width:130px" data-inquiry-status="${i.id}">${statuses.map(s=>`<option${s===i.status?' selected':''}>${s}</option>`).join('')}</select></td><td>${formatDate(i.created_at)}</td><td><button class="icon-btn danger" data-delete-inquiry="${i.id}">×</button></td></tr>`).join('');}
  function renderInquiries(){const status=$('#inquiryFilter')?.value||'All';const items=status==='All'?state.inquiries:state.inquiries.filter(i=>i.status===status);$('#inquiryRows').innerHTML=inquiryRows(items);$('#inquiryCount').textContent=`${items.length} ${items.length===1?'inquiry':'inquiries'}`;}
  function renderRecentInquiries(){const items=state.inquiries.slice(0,5);$('#recentInquiryRows').innerHTML=items.length?items.map(i=>`<tr><td><div class="table-title">${escapeHtml(i.name)}</div><div class="table-sub">${escapeHtml(i.email)}</div></td><td>${escapeHtml(i.interest)}</td><td><span class="status-pill">${escapeHtml(i.status)}</span></td><td>${formatDate(i.created_at)}</td></tr>`).join(''):'<tr><td colspan="4" class="text-muted">No inquiries yet.</td></tr>';}
  $('#inquiryFilter')?.addEventListener('change',renderInquiries);
  $('#inquiryRows')?.addEventListener('change',async e=>{const select=e.target.closest('[data-inquiry-status]');if(!select)return;try{await api(`/api/admin/inquiries/${select.dataset.inquiryStatus}`,{method:'PATCH',body:JSON.stringify({status:select.value})});await refreshAll();showToast('Inquiry status updated.');}catch(error){showToast(error.message);}});
  $('#inquiryRows')?.addEventListener('click',async e=>{const remove=e.target.closest('[data-delete-inquiry]');if(remove&&confirm('Delete this inquiry?')){await api(`/api/admin/inquiries/${remove.dataset.deleteInquiry}`,{method:'DELETE'});await refreshAll();showToast('Inquiry deleted.');}});

  document.addEventListener('keydown',event=>{if(event.key!=='Escape')return;closePropertyModal();closeHeroModal();closeSectionModal();closePageModal();});

  async function loadPublicBranding() {
    try {
      const response = await fetch('/api/site-config');
      if (!response.ok) return;
      const data = await response.json();
      const config = data.config || {}, identity = config.identity || {};
      const loginLogo = $('.login-card img'); if (loginLogo && identity.logo_dark_url) loginLogo.src = identity.logo_dark_url;
      const metaTheme = document.querySelector('meta[name="theme-color"]'); if (metaTheme && config.theme?.deep_navy) metaTheme.content = config.theme.deep_navy;
    } catch (_) {}
  }

  loadPublicBranding().finally(checkSession);
})();
